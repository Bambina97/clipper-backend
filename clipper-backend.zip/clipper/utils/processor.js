const { execSync, exec } = require("child_process");
const path = require("path");
const fs = require("fs");
const https = require("https");

const outputDir = path.join(__dirname, "../outputs");

// ─── Descargar video de YouTube con yt-dlp ───────────────────────────────────
function downloadVideo(url) {
  return new Promise((resolve, reject) => {
    const outPath = path.join(outputDir, `video_${Date.now()}.mp4`);
    const cmd = `yt-dlp -f "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]" --merge-output-format mp4 -o "${outPath}" "${url}"`;

    exec(cmd, (err, stdout, stderr) => {
      if (err) return reject(new Error("Error descargando video: " + stderr));
      resolve(outPath);
    });
  });
}

// ─── Obtener duración del video con ffprobe ───────────────────────────────────
function getVideoDuration(videoPath) {
  const result = execSync(
    `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${videoPath}"`
  ).toString().trim();
  return parseFloat(result);
}

// ─── Cortar clips con FFmpeg ──────────────────────────────────────────────────
function extractClips(videoPath, options = {}) {
  return new Promise((resolve, reject) => {
    try {
      const durMin = options.duracion === "30-60" ? 30 : 15;
      const durMax = options.duracion === "30-60" ? 60 : 30;
      const esVertical = options.formato !== "1:1";

      const totalDuration = getVideoDuration(videoPath);
      const clipDuration = (durMin + durMax) / 2; // promedio

      // Generar 3 puntos de corte distribuidos en el video
      const puntos = [
        Math.floor(totalDuration * 0.05),
        Math.floor(totalDuration * 0.35),
        Math.floor(totalDuration * 0.65),
      ];

      const clips = [];

      for (let i = 0; i < puntos.length; i++) {
        const start = puntos[i];
        const clipName = `clip_${Date.now()}_${i}.mp4`;
        const clipPath = path.join(outputDir, clipName);

        // Filtro de video: recortar a vertical 9:16 o cuadrado 1:1
        let vf = esVertical
          ? `crop=ih*9/16:ih,scale=1080:1920`
          : `crop=min(iw\\,ih):min(iw\\,ih),scale=1080:1080`;

        const cmd = `ffmpeg -y -ss ${start} -i "${videoPath}" -t ${clipDuration} -vf "${vf}" -c:v libx264 -preset fast -crf 23 -c:a aac "${clipPath}"`;

        execSync(cmd);

        clips.push({
          nombre: `Clip ${i + 1}`,
          tiempo: `${formatTime(start)} – ${formatTime(start + clipDuration)}`,
          archivo: `/outputs/${clipName}`,
          score: ["Alta energía", "Momento clave", "Buen gancho"][i],
        });
      }

      resolve(clips);
    } catch (err) {
      reject(err);
    }
  });
}

// ─── Generar subtítulos con OpenAI Whisper ────────────────────────────────────
function generateSubtitles(clipPath) {
  return new Promise((resolve, reject) => {
    const OPENAI_KEY = process.env.OPENAI_API_KEY;
    if (!OPENAI_KEY) return reject(new Error("Falta OPENAI_API_KEY en las variables de entorno"));

    const fullPath = path.join(__dirname, "../", clipPath.replace("/outputs/", "outputs/"));
    const audioPath = fullPath.replace(".mp4", ".mp3");

    // Extraer audio primero
    execSync(`ffmpeg -y -i "${fullPath}" -q:a 0 -map a "${audioPath}"`);

    // Leer archivo de audio
    const audioData = fs.readFileSync(audioPath);
    const boundary = "----FormBoundary" + Date.now();

    const body = Buffer.concat([
      Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="model"\r\n\r\nwhisper-1\r\n`),
      Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="response_format"\r\n\r\nsrt\r\n`),
      Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="audio.mp3"\r\nContent-Type: audio/mpeg\r\n\r\n`),
      audioData,
      Buffer.from(`\r\n--${boundary}--\r\n`),
    ]);

    const options = {
      hostname: "api.openai.com",
      path: "/v1/audio/transcriptions",
      method: "POST",
      headers: {
        Authorization: `Bearer ${OPENAI_KEY}`,
        "Content-Type": `multipart/form-data; boundary=${boundary}`,
        "Content-Length": body.length,
      },
    };

    const reqHttp = https.request(options, (resp) => {
      let data = "";
      resp.on("data", (chunk) => (data += chunk));
      resp.on("end", () => {
        fs.unlinkSync(audioPath); // limpiar audio temporal
        resolve(data); // devuelve el .srt como texto
      });
    });

    reqHttp.on("error", reject);
    reqHttp.write(body);
    reqHttp.end();
  });
}

// ─── Utilidad ─────────────────────────────────────────────────────────────────
function formatTime(seconds) {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

module.exports = { downloadVideo, extractClips, generateSubtitles };
