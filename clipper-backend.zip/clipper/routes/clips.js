const express = require("express");
const router = express.Router();
const { downloadVideo, extractClips, generateSubtitles } = require("../utils/processor");

// POST /api/analizar
// Recibe una URL de YouTube y devuelve clips sugeridos
router.post("/analizar", async (req, res) => {
  const { url, duracion, formato } = req.body;

  if (!url) {
    return res.status(400).json({ error: "Falta la URL del video" });
  }

  try {
    console.log(`Analizando: ${url}`);

    // 1. Descargar el video
    const videoPath = await downloadVideo(url);

    // 2. Extraer clips automáticamente
    const clips = await extractClips(videoPath, { duracion, formato });

    res.json({ ok: true, clips });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// POST /api/subtitulos
// Genera subtítulos para un clip ya procesado
router.post("/subtitulos", async (req, res) => {
  const { clipPath } = req.body;

  if (!clipPath) {
    return res.status(400).json({ error: "Falta la ruta del clip" });
  }

  try {
    const subtitulos = await generateSubtitles(clipPath);
    res.json({ ok: true, subtitulos });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
