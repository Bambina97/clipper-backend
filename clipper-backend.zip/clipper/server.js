const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");

const clipRoutes = require("./routes/clips");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Carpeta donde se guardan los clips generados
const outputDir = path.join(__dirname, "outputs");
if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir);

// Servir los clips como archivos descargables
app.use("/outputs", express.static(outputDir));

// Rutas principales
app.use("/api", clipRoutes);

// Ruta de prueba
app.get("/", (req, res) => {
  res.json({ status: "ok", message: "Clipper backend funcionando" });
});

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
